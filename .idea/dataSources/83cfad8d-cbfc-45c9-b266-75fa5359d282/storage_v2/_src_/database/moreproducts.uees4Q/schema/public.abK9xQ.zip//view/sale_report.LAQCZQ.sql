create view sale_report
            (id, product_id, product_uom, product_uom_qty, price_total, nbr, date, date_confirm, partner_id, user_id,
             company_id, delay, state, categ_id, pricelist_id, analytic_account_id, section_id, warehouse_id, shipped,
             shipped_qty_1)
as
WITH currency_rate(currency_id, rate, date_start, date_end) AS (
    SELECT r.currency_id,
           r.rate,
           r.name    AS date_start,
           (SELECT r2.name
            FROM res_currency_rate r2
            WHERE r2.name > r.name
              AND r2.currency_id = r.currency_id
            ORDER BY r2.name
            LIMIT 1) AS date_end
    FROM res_currency_rate r
)
SELECT min(l.id)                                                                      AS id,
       l.product_id,
       t.uom_id                                                                       AS product_uom,
       sum(l.product_uom_qty / u.factor * u2.factor)                                  AS product_uom_qty,
       sum(l.product_uom_qty * l.price_unit / cr.rate * (100.0 - l.discount) / 100.0) AS price_total,
       count(*)                                                                       AS nbr,
       s.date_order                                                                   AS date,
       s.date_confirm,
       s.partner_id,
       s.user_id,
       s.company_id,
       date_part('epoch'::text, avg(date_trunc('day'::text, s.date_confirm::timestamp with time zone) -
                                    date_trunc('day'::text, s.create_date)::timestamp with time zone)) /
       (24 * 60 * 60)::numeric(16, 2)::double precision                               AS delay,
       l.state,
       t.categ_id,
       s.pricelist_id,
       s.project_id                                                                   AS analytic_account_id,
       s.section_id,
       s.warehouse_id,
       s.shipped,
       s.shipped::integer                                                             AS shipped_qty_1
FROM sale_order_line l
         JOIN sale_order s ON l.order_id = s.id
         LEFT JOIN product_product p ON l.product_id = p.id
         LEFT JOIN product_template t ON p.product_tmpl_id = t.id
         LEFT JOIN product_uom u ON u.id = l.product_uom
         LEFT JOIN product_uom u2 ON u2.id = t.uom_id
         LEFT JOIN product_pricelist pp ON s.pricelist_id = pp.id
         JOIN currency_rate cr ON cr.currency_id = pp.currency_id AND
                                  cr.date_start <= COALESCE(s.date_order::timestamp with time zone, now()) AND
                                  (cr.date_end IS NULL OR
                                   cr.date_end > COALESCE(s.date_order::timestamp with time zone, now()))
GROUP BY l.product_id, l.order_id, t.uom_id, t.categ_id, s.date_order, s.date_confirm, s.partner_id, s.user_id,
         s.company_id, l.state, s.pricelist_id, s.project_id, s.section_id, s.warehouse_id, s.shipped;

alter table sale_report
    owner to odoo;

