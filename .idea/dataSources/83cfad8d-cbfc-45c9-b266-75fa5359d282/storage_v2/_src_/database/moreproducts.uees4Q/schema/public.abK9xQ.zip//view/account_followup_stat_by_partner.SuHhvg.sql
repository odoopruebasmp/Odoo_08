create view account_followup_stat_by_partner
            (id, partner_id, date_move, date_move_last, date_followup, max_followup_id, balance, company_id) as
SELECT l.partner_id * 10000::bigint + l.company_id AS id,
       l.partner_id,
       min(l.date)                                 AS date_move,
       max(l.date)                                 AS date_move_last,
       max(l.followup_date)                        AS date_followup,
       max(l.followup_line_id)                     AS max_followup_id,
       sum(l.debit - l.credit)                     AS balance,
       l.company_id
FROM account_move_line l
         LEFT JOIN account_account a ON l.account_id = a.id
WHERE a.active
  AND a.type::text = 'receivable'::text
  AND l.reconcile_id IS NULL
  AND l.partner_id IS NOT NULL
GROUP BY l.partner_id, l.company_id;

alter table account_followup_stat_by_partner
    owner to odoo;

