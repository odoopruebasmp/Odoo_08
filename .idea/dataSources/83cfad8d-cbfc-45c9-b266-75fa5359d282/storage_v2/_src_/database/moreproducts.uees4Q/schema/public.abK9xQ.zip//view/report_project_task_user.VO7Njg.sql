create view report_project_task_user
            (nbr, id, date_start, date_end, date_last_stage_update, date_deadline, no_of_days, user_id, reviewer_id,
             progress, project_id, hours_effective, priority, name, company_id, partner_id, stage_id, state,
             remaining_hours, total_hours, hours_delay, hours_planned, closing_days, opening_days, delay_endings_days)
as
SELECT (SELECT 1)                                                                                 AS nbr,
       t.id,
       t.date_start,
       t.date_end,
       t.date_last_stage_update,
       t.date_deadline,
       abs(date_part('epoch'::text, t.write_date - t.date_start) / (3600 * 24)::double precision) AS no_of_days,
       t.user_id,
       t.reviewer_id,
       t.progress,
       t.project_id,
       t.effective_hours                                                                          AS hours_effective,
       t.priority,
       t.name,
       t.company_id,
       t.partner_id,
       t.stage_id,
       t.kanban_state                                                                             AS state,
       t.remaining_hours,
       t.total_hours,
       t.delay_hours                                                                              AS hours_delay,
       t.planned_hours                                                                            AS hours_planned,
       date_part('epoch'::text, t.write_date - t.create_date) / (3600 * 24)::double precision     AS closing_days,
       date_part('epoch'::text, t.date_start - t.create_date) / (3600 * 24)::double precision     AS opening_days,
       date_part('epoch'::text, t.date_deadline::timestamp without time zone - timezone('UTC'::text, now())) /
       (3600 * 24)::double precision                                                              AS delay_endings_days
FROM project_task t
WHERE t.active = true
GROUP BY t.id, t.remaining_hours, t.effective_hours, t.progress, t.total_hours, t.planned_hours, t.delay_hours,
         t.create_date, t.write_date, t.date_start, t.date_end, t.date_deadline, t.date_last_stage_update, t.user_id,
         t.reviewer_id, t.project_id, t.priority, t.name, t.company_id, t.partner_id, t.stage_id;

alter table report_project_task_user
    owner to odoo;

