create view report_pos_order
            (id, nbr, date, product_qty, price_total, total_discount, average_price, delay_validation, partner_id,
             state, user_id, location_id, company_id, journal_id, product_id, product_categ_id)
as
SELECT min(l.id)                                               AS id,
       count(*)                                                AS nbr,
       s.date_order                                            AS date,
       sum(l.qty * u.factor)                                   AS product_qty,
       sum(l.qty * l.price_unit)                               AS price_total,
       sum(l.qty * l.price_unit * (l.discount / 100::numeric)) AS total_discount,
       sum(l.qty * l.price_unit) / sum(l.qty * u.factor)       AS average_price,
       sum(to_char(date_trunc('day'::text, s.date_order) - date_trunc('day'::text, s.create_date),
                   'DD'::text)::integer)                       AS delay_validation,
       s.partner_id,
       s.state,
       s.user_id,
       s.location_id,
       s.company_id,
       s.sale_journal                                          AS journal_id,
       l.product_id,
       pt.categ_id                                             AS product_categ_id
FROM pos_order_line l
         LEFT JOIN pos_order s ON s.id = l.order_id
         LEFT JOIN product_product p ON p.id = l.product_id
         LEFT JOIN product_template pt ON pt.id = p.product_tmpl_id
         LEFT JOIN product_uom u ON u.id = pt.uom_id
GROUP BY s.date_order, s.partner_id, s.state, pt.categ_id, s.user_id, s.location_id, s.company_id, s.sale_journal,
         l.product_id, s.create_date
HAVING sum(l.qty * u.factor) <> 0::numeric;

alter table report_pos_order
    owner to odoo;

