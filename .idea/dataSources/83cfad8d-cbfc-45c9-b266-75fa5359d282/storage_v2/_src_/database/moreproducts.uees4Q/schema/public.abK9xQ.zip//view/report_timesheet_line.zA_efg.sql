create view report_timesheet_line
            (id, date, name, month, user_id, day, invoice_id, product_id, account_id, general_account_id, quantity,
             cost) as
SELECT min(l.id)                           AS id,
       l.date,
       to_char(l.date, 'YYYY'::text)       AS name,
       to_char(l.date, 'MM'::text)         AS month,
       l.user_id,
       to_char(l.date, 'YYYY-MM-DD'::text) AS day,
       l.invoice_id,
       l.product_id,
       l.account_id,
       l.general_account_id,
       sum(l.unit_amount)                  AS quantity,
       sum(l.amount)                       AS cost
FROM account_analytic_line l
WHERE l.user_id IS NOT NULL
GROUP BY l.date, l.user_id, l.product_id, l.account_id, l.general_account_id, l.invoice_id;

alter table report_timesheet_line
    owner to odoo;

