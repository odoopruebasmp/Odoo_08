create view report_mrp_inout(id, date, value, company_id) as
SELECT min(sm.id)                        AS id,
       to_char(sm.date, 'YYYY:IW'::text) AS date,
       sum(
                   CASE
                       WHEN sl.usage::text = 'internal'::text THEN sm.price_unit * sm.product_qty::double precision
                       ELSE 0.0::double precision
                       END -
                   CASE
                       WHEN sl2.usage::text = 'internal'::text THEN sm.price_unit * sm.product_qty::double precision
                       ELSE 0.0::double precision
                       END)              AS value,
       sm.company_id
FROM stock_move sm
         LEFT JOIN product_product pp ON pp.id = sm.product_id
         LEFT JOIN product_template pt ON pt.id = pp.product_tmpl_id
         LEFT JOIN stock_location sl ON sl.id = sm.location_id
         LEFT JOIN stock_location sl2 ON sl2.id = sm.location_dest_id
WHERE sm.state::text = 'done'::text
GROUP BY (to_char(sm.date, 'YYYY:IW'::text)), sm.company_id;

alter table report_mrp_inout
    owner to odoo;

