create view report_sales_by_user_pos(id, date_order, user_id, qty, amount) as
SELECT min(po.id)                                                          AS id,
       to_char(date_trunc('day'::text, po.date_order), 'YYYY-MM-DD'::text) AS date_order,
       po.user_id,
       sum(pol.qty)                                                        AS qty,
       sum(pol.price_unit * pol.qty * (1::numeric - pol.discount / 100.0)) AS amount
FROM pos_order po,
     pos_order_line pol,
     product_product pp,
     product_template pt
WHERE pt.id = pp.product_tmpl_id
  AND pp.id = pol.product_id
  AND po.id = pol.order_id
GROUP BY (to_char(date_trunc('day'::text, po.date_order), 'YYYY-MM-DD'::text)), po.user_id;

alter table report_sales_by_user_pos
    owner to odoo;

