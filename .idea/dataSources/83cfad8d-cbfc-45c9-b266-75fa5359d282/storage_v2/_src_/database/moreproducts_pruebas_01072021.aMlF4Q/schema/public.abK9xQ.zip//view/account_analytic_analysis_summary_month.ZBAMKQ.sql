create view account_analytic_analysis_summary_month(id, account_id, month, month_id, unit_amount) as
SELECT (to_number(to_char(d.month, 'YYYYMM'::text), '999999'::text) +
        (d.account_id * 1000000::bigint)::numeric)::bigint         AS id,
       d.account_id,
       to_char(d.month, 'Mon YYYY'::text)                          AS month,
       to_number(to_char(d.month, 'YYYYMM'::text), '999999'::text) AS month_id,
       COALESCE(sum(l.unit_amount), 0.0::double precision)         AS unit_amount
FROM (SELECT d2.account_id,
             d2.month
      FROM (SELECT a.id AS account_id,
                   l_1.month
            FROM (SELECT date_trunc('month'::text, l_2.date) AS month
                  FROM account_analytic_line l_2,
                       account_analytic_journal j
                  WHERE j.type::text = 'general'::text
                  GROUP BY (date_trunc('month'::text, l_2.date))) l_1,
                 account_analytic_account a
            GROUP BY l_1.month, a.id) d2
      GROUP BY d2.account_id, d2.month) d
         LEFT JOIN (SELECT l_1.account_id,
                           date_trunc('month'::text, l_1.date) AS month,
                           sum(l_1.unit_amount)                AS unit_amount
                    FROM account_analytic_line l_1,
                         account_analytic_journal j
                    WHERE j.type::text = 'general'::text
                      AND j.id = l_1.journal_id
                    GROUP BY l_1.account_id, (date_trunc('month'::text, l_1.date))) l
                   ON d.account_id = l.account_id AND d.month = l.month
GROUP BY d.month, d.account_id;

alter table account_analytic_analysis_summary_month
    owner to odoo;

