create view report_timesheet_user(id, name, month, user_id, quantity, cost) as
SELECT min(l.id)                     AS id,
       to_char(l.date, 'YYYY'::text) AS name,
       to_char(l.date, 'MM'::text)   AS month,
       l.user_id,
       sum(l.unit_amount)            AS quantity,
       sum(l.amount)                 AS cost
FROM account_analytic_line l
WHERE l.user_id IS NOT NULL
GROUP BY l.date, (to_char(l.date, 'YYYY'::text)), (to_char(l.date, 'MM'::text)), l.user_id;

alter table report_timesheet_user
    owner to odoo;

