create view crm_lead_report
            (id, date_deadline, nbr_cases, opening_date, date_closed, date_last_stage_update, user_id, probability,
             stage_id, type, company_id, priority, section_id, campaign_id, source_id, medium_id, partner_id,
             country_id, planned_revenue, probable_revenue, create_date, delay_close, delay_expected, delay_open)
as
SELECT c.id,
       c.date_deadline,
       count(c.id)                                                                             AS nbr_cases,
       c.date_open                                                                             AS opening_date,
       c.date_closed,
       c.date_last_stage_update,
       c.user_id,
       c.probability,
       c.stage_id,
       c.type,
       c.company_id,
       c.priority,
       c.section_id,
       c.campaign_id,
       c.source_id,
       c.medium_id,
       c.partner_id,
       c.country_id,
       c.planned_revenue,
       c.planned_revenue * (c.probability / 100::double precision)                             AS probable_revenue,
       c.create_date,
       date_part('epoch'::text, c.date_closed - c.create_date) / (3600 * 24)::double precision AS delay_close,
       abs(date_part('epoch'::text, c.date_deadline::timestamp without time zone - c.date_closed) /
           (3600 * 24)::double precision)                                                      AS delay_expected,
       date_part('epoch'::text, c.date_open - c.create_date) / (3600 * 24)::double precision   AS delay_open
FROM crm_lead c
WHERE c.active = true
GROUP BY c.id;

alter table crm_lead_report
    owner to odoo;

