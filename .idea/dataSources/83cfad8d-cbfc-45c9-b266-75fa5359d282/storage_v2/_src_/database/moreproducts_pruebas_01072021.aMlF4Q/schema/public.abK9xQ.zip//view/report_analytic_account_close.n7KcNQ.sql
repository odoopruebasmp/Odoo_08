create view report_analytic_account_close
            (id, name, state, quantity, balance, partner_id, quantity_max, date_deadline) as
SELECT a.id,
       a.id               AS name,
       a.state,
       sum(l.unit_amount) AS quantity,
       sum(l.amount)      AS balance,
       a.partner_id,
       a.quantity_max,
       a.date             AS date_deadline
FROM account_analytic_line l
         RIGHT JOIN account_analytic_account a ON l.account_id = a.id
GROUP BY a.id, a.state, a.quantity_max, a.date, a.partner_id
HAVING a.quantity_max > 0::double precision AND sum(l.unit_amount) >= a.quantity_max
    OR a.date <= 'now'::text::date;

alter table report_analytic_account_close
    owner to odoo;

