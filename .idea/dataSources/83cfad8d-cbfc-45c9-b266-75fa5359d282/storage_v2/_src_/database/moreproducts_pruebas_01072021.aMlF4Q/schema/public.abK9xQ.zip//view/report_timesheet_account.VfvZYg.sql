create view report_timesheet_account(id, name, month, user_id, account_id, quantity) as
SELECT min(account_analytic_line.id)                            AS id,
       to_char(account_analytic_line.create_date, 'YYYY'::text) AS name,
       to_char(account_analytic_line.create_date, 'MM'::text)   AS month,
       account_analytic_line.user_id,
       account_analytic_line.account_id,
       sum(account_analytic_line.unit_amount)                   AS quantity
FROM account_analytic_line
GROUP BY (to_char(account_analytic_line.create_date, 'YYYY'::text)),
         (to_char(account_analytic_line.create_date, 'MM'::text)), account_analytic_line.user_id,
         account_analytic_line.account_id;

alter table report_timesheet_account
    owner to odoo;

