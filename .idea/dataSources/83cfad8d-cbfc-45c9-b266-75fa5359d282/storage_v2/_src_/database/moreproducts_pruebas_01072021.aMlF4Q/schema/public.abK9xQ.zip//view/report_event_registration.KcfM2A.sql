create view report_event_registration
            (id, event_id, user_id, user_id_registration, name_registration, company_id, event_date, nbevent,
             nbregistration, draft_state, confirm_state, event_type, seats_max, event_state, registration_state)
as
SELECT (e.id::character varying::text || '/'::text) ||
       COALESCE(r.id::character varying, ''::character varying)::text AS id,
       e.id                                                           AS event_id,
       e.user_id,
       r.user_id                                                      AS user_id_registration,
       r.name                                                         AS name_registration,
       e.company_id,
       e.date_begin                                                   AS event_date,
       count(r.id)                                                    AS nbevent,
       sum(r.nb_register)                                             AS nbregistration,
       CASE
           WHEN r.state::text = 'draft'::text THEN r.nb_register
           ELSE 0
           END                                                        AS draft_state,
       CASE
           WHEN r.state::text = ANY (ARRAY ['open'::character varying::text, 'done'::character varying::text])
               THEN r.nb_register
           ELSE 0
           END                                                        AS confirm_state,
       e.type                                                         AS event_type,
       e.seats_max,
       e.state                                                        AS event_state,
       r.state                                                        AS registration_state
FROM event_event e
         LEFT JOIN event_registration r ON e.id = r.event_id
GROUP BY r.event_id, r.user_id, r.id, r.state, r.nb_register, e.type, e.id, e.date_begin, e.user_id, e.state,
         e.company_id, e.seats_max, r.name;

alter table report_event_registration
    owner to odoo;

