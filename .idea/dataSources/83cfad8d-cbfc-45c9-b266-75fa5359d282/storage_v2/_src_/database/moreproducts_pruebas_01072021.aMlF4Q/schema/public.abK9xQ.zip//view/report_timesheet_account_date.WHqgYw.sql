create view report_timesheet_account_date(id, name, month, user_id, account_id, quantity) as
SELECT min(account_analytic_line.id)                     AS id,
       to_char(account_analytic_line.date, 'YYYY'::text) AS name,
       to_char(account_analytic_line.date, 'MM'::text)   AS month,
       account_analytic_line.user_id,
       account_analytic_line.account_id,
       sum(account_analytic_line.unit_amount)            AS quantity
FROM account_analytic_line
GROUP BY (to_char(account_analytic_line.date, 'YYYY'::text)), (to_char(account_analytic_line.date, 'MM'::text)),
         account_analytic_line.user_id, account_analytic_line.account_id;

alter table report_timesheet_account_date
    owner to odoo;

