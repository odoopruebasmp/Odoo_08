create view report_workcenter_load(id, name, hour, cycle, workcenter_id) as
SELECT min(wl.id)                                  AS id,
       to_char(p.date_planned, 'YYYY:mm:dd'::text) AS name,
       sum(wl.hour)                                AS hour,
       sum(wl.cycle)                               AS cycle,
       wl.workcenter_id
FROM mrp_production_workcenter_line wl
         LEFT JOIN mrp_production p ON p.id = wl.production_id
GROUP BY wl.workcenter_id, (to_char(p.date_planned, 'YYYY:mm:dd'::text));

alter table report_workcenter_load
    owner to odoo;

