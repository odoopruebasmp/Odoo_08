create view project_task_history_cumulative
            (id, end_date, history_id, date, task_id, type_id, user_id, kanban_state, nbr_tasks, remaining_hours,
             planned_hours, project_id)
as
SELECT (history.date::character varying::text || '-'::text) || history.history_id::character varying::text AS id,
       history.date                                                                                        AS end_date,
       history.history_id,
       history.date,
       history.task_id,
       history.type_id,
       history.user_id,
       history.kanban_state,
       history.nbr_tasks,
       history.remaining_hours,
       history.planned_hours,
       history.project_id
FROM (SELECT h.id                                                                               AS history_id,
             h.date + generate_series(0, COALESCE(h.end_date, '2017-03-31'::date) - h.date - 1) AS date,
             h.task_id,
             h.type_id,
             h.user_id,
             h.kanban_state,
             count(h.task_id)                                                                   AS nbr_tasks,
             GREATEST(h.remaining_hours, 1::numeric)                                            AS remaining_hours,
             GREATEST(h.planned_hours, 1::numeric)                                              AS planned_hours,
             t.project_id
      FROM project_task_history h
               JOIN project_task t ON h.task_id = t.id
      GROUP BY h.id, h.task_id, t.project_id) history;

alter table project_task_history_cumulative
    owner to odoo;

