create view hr_recruitment_report
            (id, date_create, date_closed, date_last_stage_update, partner_id, company_id, user_id, job_id, type_id,
             available, department_id, priority, stage_id, last_stage_id, salary_prop, salary_prop_avg, salary_exp,
             salary_exp_avg, delay_close, nbr)
as
SELECT min(s.id)                                                                              AS id,
       s.create_date                                                                          AS date_create,
       date(s.date_closed)                                                                    AS date_closed,
       s.date_last_stage_update,
       s.partner_id,
       s.company_id,
       s.user_id,
       s.job_id,
       s.type_id,
       sum(s.availability)                                                                    AS available,
       s.department_id,
       s.priority,
       s.stage_id,
       s.last_stage_id,
       sum(s.salary_proposed)                                                                 AS salary_prop,
       sum(s.salary_proposed) / count(*)::double precision                                    AS salary_prop_avg,
       sum(s.salary_expected)                                                                 AS salary_exp,
       sum(s.salary_expected) / count(*)::double precision                                    AS salary_exp_avg,
       date_part('epoch'::text, s.write_date - s.create_date) / (3600 * 24)::double precision AS delay_close,
       count(*)                                                                               AS nbr
FROM hr_applicant s
GROUP BY s.date_open, s.create_date, s.write_date, s.date_closed, s.date_last_stage_update, s.partner_id, s.company_id,
         s.user_id, s.stage_id, s.last_stage_id, s.type_id, s.priority, s.job_id, s.department_id;

alter table hr_recruitment_report
    owner to odoo;

