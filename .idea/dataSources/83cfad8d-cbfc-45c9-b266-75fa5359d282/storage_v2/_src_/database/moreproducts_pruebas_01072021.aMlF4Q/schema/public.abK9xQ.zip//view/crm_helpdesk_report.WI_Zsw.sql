create view crm_helpdesk_report
            (id, date, create_date, date_closed, state, user_id, section_id, partner_id, company_id, priority,
             date_deadline, categ_id, channel_id, planned_cost, nbr, delay_close, email, delay_expected)
as
SELECT min(c.id)                                                                               AS id,
       c.date,
       c.create_date,
       c.date_closed,
       c.state,
       c.user_id,
       c.section_id,
       c.partner_id,
       c.company_id,
       c.priority,
       c.date_deadline,
       c.categ_id,
       c.channel_id,
       c.planned_cost,
       count(*)                                                                                AS nbr,
       date_part('epoch'::text, c.date_closed - c.create_date) / (3600 * 24)::double precision AS delay_close,
       (SELECT count(mail_message.id) AS count
        FROM mail_message
        WHERE mail_message.model::text = 'crm.helpdesk'::text
          AND mail_message.res_id = c.id
          AND mail_message.type::text = 'email'::text)                                         AS email,
       abs(avg(date_part('epoch'::text, c.date_deadline::timestamp without time zone - c.date_closed)) /
           (3600 * 24)::double precision)                                                      AS delay_expected
FROM crm_helpdesk c
WHERE c.active = true
GROUP BY c.date, c.state, c.user_id, c.section_id, c.priority, c.partner_id, c.company_id, c.date_deadline,
         c.create_date, c.date_closed, c.categ_id, c.channel_id, c.planned_cost, c.id;

alter table crm_helpdesk_report
    owner to odoo;

