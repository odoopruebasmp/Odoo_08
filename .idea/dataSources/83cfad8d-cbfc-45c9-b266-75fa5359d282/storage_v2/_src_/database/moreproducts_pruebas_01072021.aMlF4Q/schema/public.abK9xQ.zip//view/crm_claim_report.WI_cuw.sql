create view crm_claim_report
            (id, claim_date, date_closed, date_deadline, user_id, stage_id, section_id, partner_id, company_id,
             categ_id, subject, nbr, priority, type_action, create_date, delay_close, email, delay_expected)
as
SELECT min(c.id)                                                                                    AS id,
       c.date                                                                                       AS claim_date,
       c.date_closed,
       c.date_deadline,
       c.user_id,
       c.stage_id,
       c.section_id,
       c.partner_id,
       c.company_id,
       c.categ_id,
       c.name                                                                                       AS subject,
       count(*)                                                                                     AS nbr,
       c.priority,
       c.type_action,
       c.create_date,
       avg(date_part('epoch'::text, c.date_closed - c.create_date)) / (3600 * 24)::double precision AS delay_close,
       (SELECT count(mail_message.id) AS count
        FROM mail_message
        WHERE mail_message.model::text = 'crm.claim'::text
          AND mail_message.res_id = c.id)                                                           AS email,
       date_part('epoch'::text, c.date_deadline::timestamp without time zone - c.date_closed) /
       (3600 * 24)::double precision                                                                AS delay_expected
FROM crm_claim c
GROUP BY c.date, c.user_id, c.section_id, c.stage_id, c.categ_id, c.partner_id, c.company_id, c.create_date, c.priority,
         c.type_action, c.date_deadline, c.date_closed, c.id;

alter table crm_claim_report
    owner to odoo;

