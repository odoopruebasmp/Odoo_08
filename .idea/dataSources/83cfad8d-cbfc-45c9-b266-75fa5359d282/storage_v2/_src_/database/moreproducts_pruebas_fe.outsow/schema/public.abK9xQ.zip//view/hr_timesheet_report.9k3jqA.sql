create view hr_timesheet_report
            (id, date, cost, quantity, account_id, journal_id, product_id, general_account_id, user_id, company_id,
             currency_id) as
SELECT min(hat.id)          AS id,
       aal.date,
       sum(aal.amount)      AS cost,
       sum(aal.unit_amount) AS quantity,
       aal.account_id,
       aal.journal_id,
       aal.product_id,
       aal.general_account_id,
       aal.user_id,
       aal.company_id,
       aal.currency_id
FROM account_analytic_line aal
         JOIN hr_analytic_timesheet hat ON hat.line_id = aal.id
GROUP BY aal.date, aal.account_id, aal.product_id, aal.general_account_id, aal.journal_id, aal.user_id, aal.company_id,
         aal.currency_id;

alter table hr_timesheet_report
    owner to odoo;

