create view account_entries_report
            (id, date, date_maturity, date_created, ref, move_state, move_line_state, reconcile_id, partner_id,
             product_id, product_uom_id, company_id, journal_id, fiscalyear_id, period_id, account_id,
             analytic_account_id, type, user_type, nbr, quantity, currency_id, amount_currency, debit, credit, balance)
as
SELECT l.id,
       am.date,
       l.date_maturity,
       l.date_created,
       am.ref,
       am.state                                         AS move_state,
       l.state                                          AS move_line_state,
       l.reconcile_id,
       l.partner_id,
       l.product_id,
       l.product_uom_id,
       am.company_id,
       am.journal_id,
       p.fiscalyear_id,
       am.period_id,
       l.account_id,
       l.analytic_account_id,
       a.type,
       a.user_type,
       1                                                AS nbr,
       l.quantity,
       l.currency_id,
       l.amount_currency,
       l.debit,
       l.credit,
       COALESCE(l.debit, 0.0) - COALESCE(l.credit, 0.0) AS balance
FROM account_move_line l
         LEFT JOIN account_account a ON l.account_id = a.id
         LEFT JOIN account_move am ON am.id = l.move_id
         LEFT JOIN account_period p ON am.period_id = p.id
WHERE l.state::text <> 'draft'::text;

alter table account_entries_report
    owner to odoo;

