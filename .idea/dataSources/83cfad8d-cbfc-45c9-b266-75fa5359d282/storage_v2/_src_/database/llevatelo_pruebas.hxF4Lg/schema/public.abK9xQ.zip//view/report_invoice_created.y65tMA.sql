create view report_invoice_created
            (id, name, type, number, partner_id, amount_untaxed, amount_total, currency_id, date_invoice, date_due,
             residual, state, origin, create_date)
as
SELECT inv.id,
       inv.name,
       inv.type,
       inv.number,
       inv.partner_id,
       inv.amount_untaxed,
       inv.amount_total,
       inv.currency_id,
       inv.date_invoice,
       inv.date_due,
       inv.residual,
       inv.state,
       inv.origin,
       inv.create_date
FROM account_invoice inv
WHERE to_date(to_char(inv.create_date, 'YYYY-MM-dd'::text), 'YYYY-MM-dd'::text) <= 'now'::text::date
  AND to_date(to_char(inv.create_date, 'YYYY-MM-dd'::text), 'YYYY-MM-dd'::text) > ('now'::text::date - 15);

alter table report_invoice_created
    owner to odoo;

