create function currency_rate_closed(date_move date, currency integer) returns numeric
    language plpgsql
as
$$
DECLARE 
                    result VARCHAR;
                    BEGIN
                    result = (SELECT rcr.rate
                    FROM res_currency_rate rcr
                    WHERE rcr.date_sin_hora::varchar like substring(date_move::varchar from 0 for 8)||'%'
                    AND rcr.currency_id = currency
                    ORDER BY date_sin_hora DESC 
                    LIMIT 1);
                    RETURN result;
                    END;
$$;

alter function currency_rate_closed(date, integer) owner to odoo;

