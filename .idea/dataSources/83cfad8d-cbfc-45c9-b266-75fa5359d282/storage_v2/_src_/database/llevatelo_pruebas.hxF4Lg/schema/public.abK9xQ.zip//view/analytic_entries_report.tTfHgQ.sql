create view analytic_entries_report
            (id, nbr, date, user_id, name, partner_id, company_id, currency_id, account_id, general_account_id,
             journal_id, move_id, product_id, product_uom_id, amount, unit_amount)
as
SELECT min(a.id)                                                 AS id,
       count(DISTINCT a.id)                                      AS nbr,
       "substring"(a.date::character varying::text, 0, 11)::date AS date,
       a.user_id,
       a.name,
       analytic.partner_id,
       a.company_id,
       a.currency_id,
       a.account_id,
       a.general_account_id,
       a.journal_id,
       a.move_id,
       a.product_id,
       a.product_uom_id,
       sum(a.amount)                                             AS amount,
       sum(a.unit_amount)                                        AS unit_amount
FROM account_analytic_line a,
     account_analytic_account analytic
WHERE analytic.id = a.account_id
GROUP BY a.date, a.user_id, a.name, analytic.partner_id, a.company_id, a.currency_id, a.account_id,
         a.general_account_id, a.journal_id, a.move_id, a.product_id, a.product_uom_id;

alter table analytic_entries_report
    owner to odoo;

