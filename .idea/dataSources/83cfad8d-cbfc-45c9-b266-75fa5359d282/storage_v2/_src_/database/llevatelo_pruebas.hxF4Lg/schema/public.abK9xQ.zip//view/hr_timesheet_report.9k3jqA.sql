create view hr_timesheet_report
            (id, date, cost, quantity, account_id, journal_id, product_id, general_account_id, user_id, company_id,
             currency_id, name, date_from, date_to, nbr, total_diff, total_timesheet, total_attendance, to_invoice,
             department_id, state)
as
WITH totals AS (
    SELECT d.sheet_id,
           d.name                                                                         AS date,
           sum(d.total_difference) / COALESCE(sum(j.count), 1::numeric)::double precision AS total_diff,
           sum(d.total_timesheet) / COALESCE(sum(j.count), 1::numeric)::double precision  AS total_timesheet,
           sum(d.total_attendance) / COALESCE(sum(j.count), 1::numeric)::double precision AS total_attendance
    FROM hr_timesheet_sheet_sheet_day d
             LEFT JOIN (SELECT h.sheet_id,
                               a.date,
                               count(*) AS count
                        FROM account_analytic_line a
                                 JOIN hr_analytic_timesheet h ON h.line_id = a.id
                        GROUP BY h.sheet_id, a.date) j ON d.sheet_id = j.sheet_id AND d.name = j.date
    GROUP BY d.sheet_id, d.name
)
SELECT min(hat.id)             AS id,
       aal.date,
       sum(aal.amount)         AS cost,
       sum(aal.unit_amount)    AS quantity,
       aal.account_id,
       aal.journal_id,
       aal.product_id,
       aal.general_account_id,
       aal.user_id,
       aal.company_id,
       aal.currency_id,
       htss.name,
       htss.date_from,
       htss.date_to,
       count(*)                AS nbr,
       sum(t.total_diff)       AS total_diff,
       sum(t.total_timesheet)  AS total_timesheet,
       sum(t.total_attendance) AS total_attendance,
       aal.to_invoice,
       htss.department_id,
       htss.state
FROM account_analytic_line aal
         JOIN hr_analytic_timesheet hat ON hat.line_id = aal.id
         LEFT JOIN hr_timesheet_sheet_sheet htss ON hat.sheet_id = htss.id
         LEFT JOIN totals t ON t.sheet_id = hat.sheet_id AND t.date = aal.date
GROUP BY aal.date, aal.account_id, aal.product_id, aal.general_account_id, aal.journal_id, aal.user_id, aal.company_id,
         aal.currency_id, htss.date_from, htss.date_to, aal.unit_amount, aal.amount, aal.to_invoice, htss.name,
         htss.state, htss.id, htss.department_id;

alter table hr_timesheet_report
    owner to odoo;

