create view stock_report_tracklots(id, location_id, product_id, tracking_id, name) as
SELECT max(report.id)  AS id,
       report.location_id,
       report.product_id,
       report.tracking_id,
       sum(report.qty) AS name
FROM (SELECT - max(sm.id)                      AS id,
             sm.location_id,
             sm.product_id,
             sm.tracking_id,
             - sum(sm.product_qty / uo.factor) AS qty
      FROM stock_move sm
               LEFT JOIN stock_location sl ON sl.id = sm.location_id
               LEFT JOIN product_uom uo ON uo.id = sm.product_uom
      WHERE sm.state::text = 'done'::text
      GROUP BY sm.location_id, sm.product_id, sm.product_uom, sm.tracking_id
      UNION ALL
      SELECT max(sm.id)                      AS id,
             sm.location_dest_id             AS location_id,
             sm.product_id,
             sm.tracking_id,
             sum(sm.product_qty / uo.factor) AS qty
      FROM stock_move sm
               LEFT JOIN stock_location sl ON sl.id = sm.location_dest_id
               LEFT JOIN product_uom uo ON uo.id = sm.product_uom
      WHERE sm.state::text = 'done'::text
      GROUP BY sm.location_dest_id, sm.product_id, sm.product_uom, sm.tracking_id) report
GROUP BY report.location_id, report.product_id, report.tracking_id;

alter table stock_report_tracklots
    owner to odoo;

