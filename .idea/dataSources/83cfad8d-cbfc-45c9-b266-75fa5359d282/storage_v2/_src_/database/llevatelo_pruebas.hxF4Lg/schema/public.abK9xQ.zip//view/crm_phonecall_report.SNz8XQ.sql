create view crm_phonecall_report
            (id, opening_date, date_closed, state, user_id, section_id, categ_id, partner_id, duration, company_id,
             priority, nbr, create_date, delay_close, delay_open)
as
SELECT c.id,
       c.date_open                                                                             AS opening_date,
       c.date_closed,
       c.state,
       c.user_id,
       c.section_id,
       c.categ_id,
       c.partner_id,
       c.duration,
       c.company_id,
       c.priority,
       1                                                                                       AS nbr,
       c.create_date,
       date_part('epoch'::text, c.date_closed - c.create_date) / (3600 * 24)::double precision AS delay_close,
       date_part('epoch'::text, c.date_open - c.create_date) / (3600 * 24)::double precision   AS delay_open
FROM crm_phonecall c;

alter table crm_phonecall_report
    owner to odoo;

