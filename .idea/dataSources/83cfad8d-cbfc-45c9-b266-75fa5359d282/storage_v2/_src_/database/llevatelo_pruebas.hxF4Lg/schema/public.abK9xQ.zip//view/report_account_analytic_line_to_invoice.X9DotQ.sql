create view report_account_analytic_line_to_invoice
            (month, name, id, product_id, account_id, amount, sale_price, unit_amount, product_uom_id) as
SELECT DISTINCT to_char(l.date, 'MM'::text)                         AS month,
                to_char(l.date, 'YYYY'::text)                       AS name,
                min(l.id)                                           AS id,
                l.product_id,
                l.account_id,
                sum(l.amount)                                       AS amount,
                sum(l.unit_amount * t.list_price::double precision) AS sale_price,
                sum(l.unit_amount)                                  AS unit_amount,
                l.product_uom_id
FROM account_analytic_line l
         LEFT JOIN product_product p ON l.product_id = p.id
         LEFT JOIN product_template t ON p.product_tmpl_id = t.id
WHERE l.invoice_id IS NULL
  AND l.to_invoice IS NOT NULL
GROUP BY (to_char(l.date, 'YYYY'::text)), (to_char(l.date, 'MM'::text)), l.product_id, l.product_uom_id, l.account_id;

alter table report_account_analytic_line_to_invoice
    owner to odoo;

