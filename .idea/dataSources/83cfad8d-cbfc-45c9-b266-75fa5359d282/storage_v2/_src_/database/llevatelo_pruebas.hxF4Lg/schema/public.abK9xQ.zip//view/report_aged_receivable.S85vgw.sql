create view report_aged_receivable(id, name) as
SELECT temp_range.id,
       temp_range.name
FROM temp_range;

alter table report_aged_receivable
    owner to odoo;

