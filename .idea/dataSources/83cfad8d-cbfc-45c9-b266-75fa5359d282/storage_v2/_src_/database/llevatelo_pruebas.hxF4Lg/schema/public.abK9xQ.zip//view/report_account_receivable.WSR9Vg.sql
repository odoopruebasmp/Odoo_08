create view report_account_receivable(id, name, balance, debit, credit, type) as
SELECT min(l.id)                                                  AS id,
       to_char(l.date::timestamp with time zone, 'YYYY:IW'::text) AS name,
       sum(l.debit - l.credit)                                    AS balance,
       sum(l.debit)                                               AS debit,
       sum(l.credit)                                              AS credit,
       a.type
FROM account_move_line l
         LEFT JOIN account_account a ON l.account_id = a.id
WHERE l.state::text <> 'draft'::text
GROUP BY (to_char(l.date::timestamp with time zone, 'YYYY:IW'::text)), a.type;

alter table report_account_receivable
    owner to odoo;

