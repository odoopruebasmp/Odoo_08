create view report_timesheet_invoice(id, user_id, account_id, manager_id, quantity, amount_invoice) as
SELECT min(l.id)                                           AS id,
       l.user_id,
       l.account_id,
       a.user_id                                           AS manager_id,
       sum(l.unit_amount)                                  AS quantity,
       sum(l.unit_amount * t.list_price::double precision) AS amount_invoice
FROM account_analytic_line l
         LEFT JOIN hr_timesheet_invoice_factor f ON l.to_invoice = f.id
         LEFT JOIN account_analytic_account a ON l.account_id = a.id
         LEFT JOIN product_product p ON l.to_invoice = f.id
         LEFT JOIN product_template t ON l.to_invoice = f.id
WHERE l.to_invoice IS NOT NULL
  AND l.invoice_id IS NULL
GROUP BY l.user_id, l.account_id, a.user_id;

alter table report_timesheet_invoice
    owner to odoo;

