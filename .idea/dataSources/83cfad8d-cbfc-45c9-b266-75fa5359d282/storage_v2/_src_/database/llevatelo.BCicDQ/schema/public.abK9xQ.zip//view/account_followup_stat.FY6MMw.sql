create view account_followup_stat
            (id, partner_id, date_move, date_move_last, date_followup, followup_id, debit, credit, balance, company_id,
             blocked, period_id)
as
SELECT l.id,
       l.partner_id,
       min(l.date)             AS date_move,
       max(l.date)             AS date_move_last,
       max(l.followup_date)    AS date_followup,
       max(l.followup_line_id) AS followup_id,
       sum(l.debit)            AS debit,
       sum(l.credit)           AS credit,
       sum(l.debit - l.credit) AS balance,
       l.company_id,
       l.blocked,
       l.period_id
FROM account_move_line l
         LEFT JOIN account_account a ON l.account_id = a.id
WHERE a.active
  AND a.type::text = 'receivable'::text
  AND l.reconcile_id IS NULL
  AND l.partner_id IS NOT NULL
GROUP BY l.id, l.partner_id, l.company_id, l.blocked, l.period_id;

alter table account_followup_stat
    owner to odoo;

