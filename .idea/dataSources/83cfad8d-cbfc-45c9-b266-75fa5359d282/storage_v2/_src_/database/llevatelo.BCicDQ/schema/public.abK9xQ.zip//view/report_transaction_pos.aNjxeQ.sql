create view report_transaction_pos
            (id, no_trans, amount, disc, date_create, user_id, journal_id, jl_id, invoice_id, product_nb) as
SELECT min(absl.id)                                                           AS id,
       count(absl.id)                                                         AS no_trans,
       sum(absl.amount)                                                       AS amount,
       sum((100.0 - line.discount) * line.price_unit * line.qty / 100.0)      AS disc,
       to_char(date_trunc('day'::text, absl.create_date), 'YYYY-MM-DD'::text) AS date_create,
       po.user_id,
       po.sale_journal                                                        AS journal_id,
       abs.journal_id                                                         AS jl_id,
       count(po.invoice_id)                                                   AS invoice_id,
       count(p.id)                                                            AS product_nb
FROM account_bank_statement_line absl,
     account_bank_statement abs,
     product_product p,
     pos_order_line line,
     pos_order po
WHERE absl.pos_statement_id = po.id
  AND line.order_id = po.id
  AND line.product_id = p.id
  AND absl.statement_id = abs.id
GROUP BY po.user_id, po.sale_journal, abs.journal_id,
         (to_char(date_trunc('day'::text, absl.create_date), 'YYYY-MM-DD'::text));

alter table report_transaction_pos
    owner to odoo;

