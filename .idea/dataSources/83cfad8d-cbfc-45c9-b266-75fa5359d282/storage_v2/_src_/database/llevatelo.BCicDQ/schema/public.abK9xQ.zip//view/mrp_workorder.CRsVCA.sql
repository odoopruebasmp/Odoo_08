create view mrp_workorder
            (date, id, product_id, total_hours, delay, total_cost, production_id, workcenter_id, total_cycles, nbr,
             product_qty, state)
as
SELECT date(wl.date_planned)                         AS date,
       min(wl.id)                                    AS id,
       mp.product_id,
       sum(wl.hour)                                  AS total_hours,
       avg(wl.delay)                                 AS delay,
       w.costs_hour * sum(wl.hour)::double precision AS total_cost,
       wl.production_id,
       wl.workcenter_id,
       sum(wl.cycle)                                 AS total_cycles,
       count(*)                                      AS nbr,
       sum(mp.product_qty)                           AS product_qty,
       wl.state
FROM mrp_production_workcenter_line wl
         LEFT JOIN mrp_workcenter w ON w.id = wl.workcenter_id
         LEFT JOIN mrp_production mp ON mp.id = wl.production_id
GROUP BY w.costs_hour, mp.product_id, mp.name, wl.state, wl.date_planned, wl.production_id, wl.workcenter_id;

alter table mrp_workorder
    owner to odoo;

