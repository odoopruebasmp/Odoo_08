create view report_account_type_sales
            (id, name, month, amount_total, currency_id, period_id, product_id, quantity, user_type) as
SELECT min(inv_line.id)                                                  AS id,
       to_char(inv.date_invoice::timestamp with time zone, 'YYYY'::text) AS name,
       to_char(inv.date_invoice::timestamp with time zone, 'MM'::text)   AS month,
       sum(inv_line.price_subtotal)                                      AS amount_total,
       inv.currency_id,
       inv.period_id,
       inv_line.product_id,
       sum(inv_line.quantity)                                            AS quantity,
       account.user_type
FROM account_invoice_line inv_line
         JOIN account_invoice inv ON inv.id = inv_line.invoice_id
         JOIN account_account account ON account.id = inv_line.account_id
WHERE inv.state::text = ANY (ARRAY ['open'::character varying::text, 'paid'::character varying::text])
GROUP BY (to_char(inv.date_invoice::timestamp with time zone, 'YYYY'::text)),
         (to_char(inv.date_invoice::timestamp with time zone, 'MM'::text)), inv.currency_id, inv.period_id,
         inv_line.product_id, account.user_type;

alter table report_account_type_sales
    owner to odoo;

