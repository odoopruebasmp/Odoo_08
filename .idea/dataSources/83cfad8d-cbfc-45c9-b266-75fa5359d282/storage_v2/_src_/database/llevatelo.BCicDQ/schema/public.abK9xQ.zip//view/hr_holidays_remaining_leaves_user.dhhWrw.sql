create view hr_holidays_remaining_leaves_user(id, name, no_of_leaves, user_id, leave_type) as
SELECT min(hrs.id)             AS id,
       rr.name,
       sum(hrs.number_of_days) AS no_of_leaves,
       rr.user_id,
       hhs.name                AS leave_type
FROM hr_holidays hrs,
     hr_employee hre,
     resource_resource rr,
     hr_holidays_status hhs
WHERE hrs.employee_id = hre.id
  AND hre.resource_id = rr.id
  AND hhs.id = hrs.holiday_status_id
GROUP BY rr.name, rr.user_id, hhs.name;

alter table hr_holidays_remaining_leaves_user
    owner to odoo;

