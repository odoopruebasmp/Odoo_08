create view account_treasury_report (id, fiscalyear_id, period_id, debit, credit, balance, date, company_id) as
SELECT p.id,
       p.fiscalyear_id,
       p.id                    AS period_id,
       sum(l.debit)            AS debit,
       sum(l.credit)           AS credit,
       sum(l.debit - l.credit) AS balance,
       p.date_start            AS date,
       am.company_id
FROM account_move_line l
         LEFT JOIN account_account a ON l.account_id = a.id
         LEFT JOIN account_move am ON am.id = l.move_id
         LEFT JOIN account_period p ON am.period_id = p.id
WHERE l.state::text <> 'draft'::text
  AND a.type::text = 'liquidity'::text
GROUP BY p.id, p.fiscalyear_id, p.date_start, am.company_id;

alter table account_treasury_report
    owner to odoo;

